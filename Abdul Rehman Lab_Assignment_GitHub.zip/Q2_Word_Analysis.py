# Q2: Sentence and Word Analysis

def analyze_sentence(sentence):
    words = sentence.split()
    total_words = len(words)
    total_characters = len(sentence)

    if len(words) > 0:
        longest_word = words[0]
        shortest_word = words[0]

        for word in words:
            if len(word) > len(longest_word):
                longest_word = word
            if len(word) < len(shortest_word):
                shortest_word = word
    else:
        longest_word = ""
        shortest_word = ""

    vowels = 0
    for character in sentence.lower():
        if character in "aeiou":
            vowels = vowels + 1

    unique_words = set(words)
    alphabetical_words = sorted(unique_words)

    return total_words, total_characters, longest_word, shortest_word, vowels, unique_words, alphabetical_words


sentence = input("Enter a sentence: ")
total_words, total_characters, longest_word, shortest_word, vowels, unique_words, alphabetical_words = analyze_sentence(sentence)

print("\nWORD ANALYSIS")
print("Total words:", total_words)
print("Total characters:", total_characters)
print("Longest word:", longest_word)
print("Shortest word:", shortest_word)
print("Number of vowels:", vowels)
print("Unique words:", unique_words)
print("Alphabetical order:", alphabetical_words)

with open("word_analysis.txt", "w") as file:
    file.write("WORD ANALYSIS\n")
    file.write("Total words: " + str(total_words) + "\n")
    file.write("Total characters: " + str(total_characters) + "\n")
    file.write("Longest word: " + longest_word + "\n")
    file.write("Shortest word: " + shortest_word + "\n")
    file.write("Number of vowels: " + str(vowels) + "\n")
    file.write("Unique words: " + str(unique_words) + "\n")
    file.write("Alphabetical order: " + str(alphabetical_words) + "\n")

print("Analysis saved in word_analysis.txt")
