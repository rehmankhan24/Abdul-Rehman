# Lab Assignment 01 — Python

Beginner-friendly solutions for the five questions in the Fundamentals of AI lab assignment.

## Files
- Q1_Student_Result.py — student marks, percentage, grade, highest percentage, results.txt
- Q2_Word_Analysis.py — sentence analysis, word_analysis.txt
- Q3_Shopping_Bill.py — shopping bill and discount, bill.txt
- Q4_Calculator.py — calculator with separate functions
- Q5_Restaurant_Order.py — restaurant ordering, orders.txt

## How to run
Open a `.py` file in PyCharm or run it with Python. Run each program separately.
Text output files are created in the program's working directory.

## GitHub
Upload these `.py` files and this README to your repository. Check that the code matches your instructor's requirements and make sure you understand it before submission.
