# Q4: Simple Calculator

def add(a, b):
    return a + b

def subtract(a, b):
    return a - b

def multiply(a, b):
    return a * b

def divide(a, b):
    return a / b

def modulus(a, b):
    return a % b


while True:
    print("\nCALCULATOR")
    num1 = float(input("Enter first number: "))
    num2 = float(input("Enter second number: "))
    operation = input("Enter operation (+, -, *, /, %): ")

    if operation == "+":
        result = add(num1, num2)
    elif operation == "-":
        result = subtract(num1, num2)
    elif operation == "*":
        result = multiply(num1, num2)
    elif operation == "/":
        if num2 == 0:
            print("Cannot divide by zero.")
            continue
        result = divide(num1, num2)
    elif operation == "%":
        if num2 == 0:
            print("Cannot use zero for modulus.")
            continue
        result = modulus(num1, num2)
    else:
        print("Invalid operation.")
        continue

    print("Result:", result)
    again = input("Another calculation? (yes/no): ").lower()

    if again != "yes":
        print("Calculator closed.")
        break
