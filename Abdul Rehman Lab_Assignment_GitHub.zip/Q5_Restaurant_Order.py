# Q5: Small Restaurant Program

menu = {
    1: {"name": "Burger", "price": 500},
    2: {"name": "Pizza", "price": 800},
    3: {"name": "Fries", "price": 250},
    4: {"name": "Drink", "price": 150}
}

def calculate_price(price, quantity):
    return price * quantity


orders = []

while True:
    print("\nRESTAURANT MENU")
    print("1. Burger - Rs. 500")
    print("2. Pizza - Rs. 800")
    print("3. Fries - Rs. 250")
    print("4. Drink - Rs. 150")
    print("5. Finish order")

    choice = int(input("Select an item: "))

    if choice == 5:
        break

    if choice not in menu:
        print("Invalid choice. Try again.")
        continue

    quantity = int(input("Enter quantity: "))
    item = menu[choice]
    total = calculate_price(item["price"], quantity)

    order = {
        "name": item["name"],
        "price": item["price"],
        "quantity": quantity,
        "total": total
    }
    orders.append(order)
    print(item["name"], "added. Total: Rs.", total)

final_bill = 0

print("\nFINAL BILL")
with open("orders.txt", "w") as file:
    file.write("RESTAURANT BILL\n")

    for order in orders:
        line = (
            order["name"] + " | Price: Rs. " + str(order["price"]) +
            " | Quantity: " + str(order["quantity"]) +
            " | Total: Rs. " + str(order["total"]) + "\n"
        )
        print(line, end="")
        file.write(line)
        final_bill = final_bill + order["total"]

    print("Final Bill: Rs.", final_bill)
    file.write("Final Bill: Rs. " + str(final_bill) + "\n")

print("Bill saved in orders.txt")
