# Q1: Student Result Management System

students = []

def calculate_result(marks):
    total = marks[0] + marks[1] + marks[2]
    percentage = total / 3

    if percentage >= 80:
        grade = "A"
    elif percentage >= 70:
        grade = "B"
    elif percentage >= 60:
        grade = "C"
    elif percentage >= 50:
        grade = "D"
    else:
        grade = "F"

    return total, percentage, grade


for i in range(5):
    print("\nStudent", i + 1)
    name = input("Enter student name: ")
    roll_no = input("Enter roll number: ")

    python = float(input("Enter Python marks: "))
    ai = float(input("Enter AI marks: "))
    maths = float(input("Enter Mathematics marks: "))

    student = {
        "name": name,
        "roll_no": roll_no,
        "marks": [python, ai, maths]
    }
    students.append(student)

highest_percentage = -1
highest_student = {}

with open("results.txt", "w") as file:
    file.write("STUDENT RESULTS\n")

    for student in students:
        total, percentage, grade = calculate_result(student["marks"])

        result = (
            "\nName: " + student["name"] +
            "\nRoll Number: " + student["roll_no"] +
            "\nTotal Marks: " + str(total) +
            "\nPercentage: " + str(round(percentage, 2)) + "%" +
            "\nGrade: " + grade + "\n"
        )

        print(result)
        file.write(result)

        if percentage > highest_percentage:
            highest_percentage = percentage
            highest_student = student

    best = (
        "\nHighest Percentage: " + highest_student["name"] +
        " (" + str(round(highest_percentage, 2)) + "%)\n"
    )
    print(best)
    file.write(best)

print("Results saved in results.txt")
