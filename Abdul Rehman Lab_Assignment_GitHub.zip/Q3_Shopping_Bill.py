# Q3: Shopping Program

products = []

def calculate_bill(products):
    subtotal = 0

    for product in products:
        product["total"] = product["price"] * product["quantity"]
        subtotal = subtotal + product["total"]

    if subtotal > 10000:
        discount = subtotal * 0.10
    else:
        discount = 0

    final_bill = subtotal - discount
    return subtotal, discount, final_bill


for i in range(5):
    print("\nProduct", i + 1)
    name = input("Enter product name: ")
    price = float(input("Enter price: Rs. "))
    quantity = int(input("Enter quantity: "))

    product = {
        "name": name,
        "price": price,
        "quantity": quantity
    }
    products.append(product)

subtotal, discount, final_bill = calculate_bill(products)

most_expensive = products[0]
for product in products:
    if product["price"] > most_expensive["price"]:
        most_expensive = product

print("\nSHOPPING BILL")
with open("bill.txt", "w") as file:
    file.write("SHOPPING BILL\n")

    for product in products:
        line = (
            product["name"] + " | Price: Rs. " + str(product["price"]) +
            " | Quantity: " + str(product["quantity"]) +
            " | Total: Rs. " + str(product["total"]) + "\n"
        )
        print(line, end="")
        file.write(line)

    print("Subtotal: Rs.", subtotal)
    print("Discount: Rs.", discount)
    print("Final Bill: Rs.", final_bill)
    print("Most expensive product:", most_expensive["name"])

    file.write("Subtotal: Rs. " + str(subtotal) + "\n")
    file.write("Discount: Rs. " + str(discount) + "\n")
    file.write("Final Bill: Rs. " + str(final_bill) + "\n")
    file.write("Most expensive product: " + most_expensive["name"] + "\n")

print("Bill saved in bill.txt")
